/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pessoa;

/**
 *
 * @author dti
 */
public class Principal {
    public static void main(String[] args){
       Pessoa pessoa1 = new Pessoa("","","");
       pessoa1.inserirDadosPessoa();
       pessoa1.apresentarPessoa();

    }

   
 
    }
    

