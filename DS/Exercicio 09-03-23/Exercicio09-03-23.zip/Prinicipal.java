/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.existencia;

/**
 *
 * @author dti
 */
public class Prinicipal {
    public static void main(String[] args){
    //instanciação do objeto
    Usuario usuario1 = new Usuario("Bartholomew","","","");
    //chamada ao provarExistencia
    usuario1.provarExistencia();
    
}
}

